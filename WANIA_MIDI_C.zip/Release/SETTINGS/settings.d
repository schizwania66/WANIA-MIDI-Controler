SETTINGS/settings.o: ../SETTINGS/settings.c ../SETTINGS/settings.h

../SETTINGS/settings.h:
