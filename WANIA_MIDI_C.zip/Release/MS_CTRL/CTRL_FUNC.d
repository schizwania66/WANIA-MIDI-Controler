MS_CTRL/CTRL_FUNC.o: ../MS_CTRL/CTRL_FUNC.c \
 ../MS_CTRL/../SETTINGS/settings.h ../MS_CTRL/../MS_MIDI/MS_MIDI.h \
 ../MS_CTRL/../LCD/LCD.h ../MS_CTRL/CTRL_FUNC.h

../MS_CTRL/../SETTINGS/settings.h:

../MS_CTRL/../MS_MIDI/MS_MIDI.h:

../MS_CTRL/../LCD/LCD.h:

../MS_CTRL/CTRL_FUNC.h:
