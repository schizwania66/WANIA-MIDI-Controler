################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../MS_CTRL/CTRL_FUNC.c 

OBJS += \
./MS_CTRL/CTRL_FUNC.o 

C_DEPS += \
./MS_CTRL/CTRL_FUNC.d 


# Each subdirectory must supply rules for building sources it contributes
MS_CTRL/%.o: ../MS_CTRL/%.c MS_CTRL/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: AVR Compiler'
	avr-gcc -Wall -Os -fpack-struct -fshort-enums -ffunction-sections -fdata-sections -std=gnu99 -funsigned-char -funsigned-bitfields -mmcu=atmega32 -DF_CPU=16000000UL -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


