################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../MS_MIDI/MS_MIDI.c 

OBJS += \
./MS_MIDI/MS_MIDI.o 

C_DEPS += \
./MS_MIDI/MS_MIDI.d 


# Each subdirectory must supply rules for building sources it contributes
MS_MIDI/%.o: ../MS_MIDI/%.c MS_MIDI/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: AVR Compiler'
	avr-gcc -Wall -Os -fpack-struct -fshort-enums -ffunction-sections -fdata-sections -std=gnu99 -funsigned-char -funsigned-bitfields -mmcu=atmega32 -DF_CPU=16000000UL -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


