MS_MIDI/MS_MIDI.o: ../MS_MIDI/MS_MIDI.c ../MS_MIDI/MS_MIDI.h \
 ../MS_MIDI/../SETTINGS/settings.h

../MS_MIDI/MS_MIDI.h:

../MS_MIDI/../SETTINGS/settings.h:
