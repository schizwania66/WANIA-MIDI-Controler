main.o: ../main.c ../MS_MIDI/MS_MIDI.h ../SETTINGS/settings.h \
 ../LCD/LCD.h ../MS_CTRL/CTRL_FUNC.h

../MS_MIDI/MS_MIDI.h:

../SETTINGS/settings.h:

../LCD/LCD.h:

../MS_CTRL/CTRL_FUNC.h:
